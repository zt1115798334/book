<template lang='jade'>
  button(title='start')
    i.glyphicon.glyphicon-play
  button(title='pause')
    i.glyphicon.glyphicon-pause
  button(title='stop')
    i.glyphicon.glyphicon-stop
</template>

<style scoped>
</style>

<script>
</script>
