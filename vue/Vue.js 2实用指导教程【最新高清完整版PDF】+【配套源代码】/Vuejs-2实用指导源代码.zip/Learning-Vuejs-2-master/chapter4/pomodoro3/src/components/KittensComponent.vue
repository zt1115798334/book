<template>
  <div class="well">
    <img />
  </div>
</template>

<style scoped>
</style>

<script>
</script>
