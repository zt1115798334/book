export const WORKING_TIME = 0.1 * 60
export const RESTING_TIME = 5 * 60
export const KITTEN_TIME = 5
