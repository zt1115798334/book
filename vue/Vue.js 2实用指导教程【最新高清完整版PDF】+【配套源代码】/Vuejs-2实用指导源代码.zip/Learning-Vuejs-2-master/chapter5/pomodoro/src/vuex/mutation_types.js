export const START = 'START'
export const PAUSE = 'PAUSE'
export const STOP = 'STOP'
