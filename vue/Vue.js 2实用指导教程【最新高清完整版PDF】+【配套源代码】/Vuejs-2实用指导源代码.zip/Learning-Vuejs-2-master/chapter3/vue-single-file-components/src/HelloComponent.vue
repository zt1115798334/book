<template lang="jade">
  h1 {{ msg }}
</template>

<!--<script >-->
  <!--export default {-->
    <!--data () {-->
    <!--return {-->
      <!--msg: "Hello!"-->
    <!--}-->
  <!--}-->
  <!--}-->
<!--</script>-->


<script lang="coffee">
  Object.defineProperty exports, '__esModule', value: true
  exports.default = data: ->
  { msg: 'Hello!' }
</script>

<!--<style lang="sass" scoped>-->
  <!--$red: #ff0000;-->

  <!--h1 {color: $red;}-->
<!--</style>-->
