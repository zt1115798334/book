import Vue from 'vue'
import HelloComponent from './HelloComponent.vue'

new Vue({
  el: '#app',
  components: { HelloComponent }
});