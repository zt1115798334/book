<template>
  <div>
    <button title="start">
      <i class="glyphicon glyphicon-play"></i>
    </button>
    <button title="pause">
      <i class="glyphicon glyphicon-pause"></i>
    </button>
    <button title="stop">
      <i class="glyphicon glyphicon-stop"></i>
    </button>
  </div>
</template>

<style scoped>
</style>

<script>
</script>
