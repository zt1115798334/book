<template>
  <h3>{{ title }}</h3>
</template>

<style scoped>
</style>

<script>
</script>
