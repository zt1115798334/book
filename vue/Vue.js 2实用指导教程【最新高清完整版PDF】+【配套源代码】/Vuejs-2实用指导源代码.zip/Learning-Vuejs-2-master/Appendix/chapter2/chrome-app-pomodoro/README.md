* Open Chrome and go to > Tools > Extensions.
* Click Developer mode > Load unpacked extensions
* Browse to and Select this folder
* Open a new tab in Chrome to see if your app loads and functions correctly.